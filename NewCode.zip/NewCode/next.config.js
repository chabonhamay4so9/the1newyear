/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  env: {
    url:"https://bookpostponemoreover.com/k439c0hqe8?key=19fc64e0f360f39f6a49bb38c40675d1"
  },
}

module.exports = nextConfig
